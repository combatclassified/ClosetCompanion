package com.example.closetcompanion.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.closetcompanion.R

class LandingPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_landing_page)
    }
}