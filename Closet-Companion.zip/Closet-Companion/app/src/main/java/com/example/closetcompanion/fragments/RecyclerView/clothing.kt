package com.example.closetcompanion.fragments.RecyclerView

class clothing : ArrayList<closetItem>()